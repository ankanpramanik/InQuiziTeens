<?php

if($_POST['otp']=="1234"){header:("Location:1.php");}
else{header("Location:2.php");}
?>

<!DOCTYPE html>
<!--[if lt IE 7]>      
<html class="no-js lt-ie9 lt-ie8 lt-ie7">
   <![endif]-->
<!--[if IE 7]>         
   <html class="no-js lt-ie9 lt-ie8">
      <![endif]-->
<!--[if IE 8]>         
      <html class="no-js lt-ie9">
         <![endif]-->
<!--[if gt IE 8]>      
         <html class="no-js">
            <!--<![endif]-->
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>InQuiziTeens :: Verify Email</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="style.css">
  <link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
  <link rel="manifest" href="favicon/site.webmanifest">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

</head>

<body>
  <div class="loader-wrapper">
    <!-- Loading square for squar.red network -->
    <span class="loader"><span class="loader-inner"></span></span>
  </div>
  <div class="login-page">
    <div class="form">
      
      <form class="login-form" method="POST">
        <p>Enter the 4 digit OTP sent to your registered email address</p>
        <input type="text" pattern=".{4,}" name="otp" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" placeholder="Enter OTP here" title="Enter the 4 digit number OTP sent to your registered email address" maxlength="4" required />
        
        <button>verify</button>
        
      </form>

      <p class="otp-error" style="color: red; text-align: justify;" >
    <?php
    if(isset($_SESSION['error'])) echo $_SESSION['error'];
    unset($_SESSION['error']);?>
    </p>
    </div>
  </div>
  <footer>
    <p>Copyright &copy 2021 | We'd love to hear from you: <a id="mail"
        href="mailto:inquiziteen@gmail.com">inquiziteen@gmail.com</a></p>
  </footer>
  <script src="main.js" async defer></script>
</body>

</html>